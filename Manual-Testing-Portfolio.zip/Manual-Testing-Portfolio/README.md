# Manual Testing Portfolio

**Author:** Manik Bhosale  
**Focus:** Manual Testing | Functional Testing | Test Case Design | Bug Reporting

## Project
This portfolio demonstrates a sample manual-testing workflow for a demo web application's **Login** and **Registration** features.

> This is a practice project. The test cases, sample defects, execution results, and reports are illustrative and are not evidence of testing a real production application.

## Repository Structure
- `Test-Plan/Test_Plan.pdf` — scope, approach, environment, entry/exit criteria.
- `Test-Cases/Test_Cases.xlsx` — detailed test cases with expected and sample actual results.
- `Bug-Reports/Bug_Report.xlsx` — illustrative defect reports.
- `Test-Scenarios/Test_Scenarios.xlsx` — high-level scenarios.
- `Screenshots/` — add screenshots captured from the demo application during your own execution.
- `Test-Summary/Test_Summary_Report.pdf` — illustrative execution summary.

## Sample Test Scope
- Login with valid and invalid credentials
- Required-field validation
- Password masking
- Registration form validation
- Email format and password confirmation

## Tools / Techniques
- Manual testing
- Equivalence partitioning
- Boundary value analysis
- Positive and negative testing
- Defect reporting

## How to Use
1. Review the test plan.
2. Execute each test case against a demo application.
3. Replace the sample `Actual Result` and `Status` with your observed results.
4. Capture genuine screenshots and place them in `Screenshots/`.
5. Update the bug report with reproducible defects only.

## Important
Do not claim the sample defects were found in a real application. Update all execution evidence before presenting this portfolio to recruiters.
