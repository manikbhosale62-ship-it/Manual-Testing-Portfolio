Add genuine screenshots captured during your own test execution here. Do not use fabricated evidence.
